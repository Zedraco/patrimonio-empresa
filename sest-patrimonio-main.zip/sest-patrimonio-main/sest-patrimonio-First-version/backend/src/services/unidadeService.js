const unidadeModel = require("../models/unidadeModel");

async function listar() {
    return await unidadeModel.listar();
}

async function buscarPorId(id) {
    return await unidadeModel.buscarPorId(id);
}

async function criar(dados) {

    if (!dados.nome)
        throw new Error("Nome é obrigatório.");

    if (!dados.tipo)
        throw new Error("Tipo é obrigatório.");

    if (!["SEST", "SENAT"].includes(dados.tipo))
        throw new Error("Tipo inválido.");

    return await unidadeModel.criar(
        dados.nome,
        dados.tipo
    );
}

async function atualizar(id, dados) {

    return await unidadeModel.atualizar(
        id,
        dados.nome,
        dados.tipo
    );

}

async function deletar(id) {

    await unidadeModel.deletar(id);

}

module.exports = {
    listar,
    buscarPorId,
    criar,
    atualizar,
    deletar
};