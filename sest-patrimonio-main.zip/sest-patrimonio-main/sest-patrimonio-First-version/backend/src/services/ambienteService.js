const ambienteModel = require("../models/ambienteModel");

async function listar() {
    return await ambienteModel.listar();
}

async function buscarPorId(id) {
    return await ambienteModel.buscarPorId(id);
}

async function criar(dados) {

    if (!dados.codigo) {
        throw new Error("Código é obrigatório.");
    }

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.tipo) {
        throw new Error("Tipo é obrigatório.");
    }

    if (!dados.setor_id) {
        throw new Error("Setor é obrigatório.");
    }

    return await ambienteModel.criar(
        dados.codigo,
        dados.nome,
        dados.tipo,
        dados.descricao,
        dados.setor_id
    );
}

async function atualizar(id, dados) {

    if (!dados.codigo) {
        throw new Error("Código é obrigatório.");
    }

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.tipo) {
        throw new Error("Tipo é obrigatório.");
    }

    if (!dados.setor_id) {
        throw new Error("Setor é obrigatório.");
    }

    return await ambienteModel.atualizar(
        id,
        dados.codigo,
        dados.nome,
        dados.tipo,
        dados.descricao,
        dados.setor_id
    );
}

async function deletar(id) {
    await ambienteModel.deletar(id);
}

module.exports = {
    listar,
    buscarPorId,
    criar,
    atualizar,
    deletar
};