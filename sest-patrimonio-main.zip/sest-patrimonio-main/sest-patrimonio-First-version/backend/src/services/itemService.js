const itemModel = require("../models/itemModel");

async function listar() {
    return await itemModel.listar();
}

async function listarPorAmbiente(ambiente_id) {
    return await itemModel.listarPorAmbiente(ambiente_id);
}

async function buscarPorId(id) {
    return await itemModel.buscarPorId(id);
}

async function criar(dados) {

    if (!dados.codigo_patrimonio) {
        throw new Error("Código de patrimônio é obrigatório.");
    }

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.ambiente_id) {
        throw new Error("Ambiente é obrigatório.");
    }

    const quantidade = dados.quantidade || 1;

    if (quantidade < 1) {
        throw new Error("A quantidade deve ser maior que zero.");
    }

    return await itemModel.criar(
        dados.codigo_patrimonio,
        dados.nome,
        dados.descricao,
        quantidade,
        dados.ambiente_id
    );
}

async function atualizar(id, dados) {

    if (!dados.codigo_patrimonio) {
        throw new Error("Código de patrimônio é obrigatório.");
    }

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.ambiente_id) {
        throw new Error("Ambiente é obrigatório.");
    }

    if (!dados.quantidade || dados.quantidade < 1) {
        throw new Error("A quantidade deve ser maior que zero.");
    }

    return await itemModel.atualizar(
        id,
        dados.codigo_patrimonio,
        dados.nome,
        dados.descricao,
        dados.quantidade,
        dados.ambiente_id
    );
}

async function listarPatrimonio() {
    return await itemModel.listarPatrimonio();
}

async function deletar(id) {
    await itemModel.deletar(id);
}

module.exports = {
    listar,
    listarPorAmbiente,
    buscarPorId,
    criar,
    atualizar,
    deletar,
    listarPatrimonio
};