const setorModel = require("../models/setorModel");

async function listar() {
    return await setorModel.listar();
}

async function buscarPorId(id) {
    return await setorModel.buscarPorId(id);
}

async function criar(dados) {

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.unidade_id) {
        throw new Error("Unidade é obrigatória.");
    }

    return await setorModel.criar(
        dados.nome,
        dados.descricao,
        dados.unidade_id
    );
}

async function atualizar(id, dados) {

    if (!dados.nome) {
        throw new Error("Nome é obrigatório.");
    }

    if (!dados.unidade_id) {
        throw new Error("Unidade é obrigatória.");
    }

    return await setorModel.atualizar(
        id,
        dados.nome,
        dados.descricao,
        dados.unidade_id
    );
}

async function deletar(id) {
    await setorModel.deletar(id);
}

module.exports = {
    listar,
    buscarPorId,
    criar,
    atualizar,
    deletar
};