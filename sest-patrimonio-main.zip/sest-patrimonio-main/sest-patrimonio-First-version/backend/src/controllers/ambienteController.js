const ambienteService = require("../services/ambienteService");

class AmbienteController {

    async listar(req, res) {

        try {

            const ambientes = await ambienteService.listar();

            res.json(ambientes);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao listar ambientes."
            });
        }
    }

    async buscarPorId(req, res) {

        try {

            const ambiente = await ambienteService.buscarPorId(
                req.params.id
            );

            if (!ambiente) {
                return res.status(404).json({
                    erro: "Ambiente não encontrado."
                });
            }

            res.json(ambiente);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao buscar ambiente."
            });
        }
    }

    async criar(req, res) {

        try {

            const ambiente = await ambienteService.criar(req.body);

            res.status(201).json(ambiente);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }

    async atualizar(req, res) {

        try {

            const ambiente = await ambienteService.atualizar(
                req.params.id,
                req.body
            );

            if (!ambiente) {
                return res.status(404).json({
                    erro: "Ambiente não encontrado."
                });
            }

            res.json(ambiente);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }

    async deletar(req, res) {

        try {

            const ambiente = await ambienteService.buscarPorId(
                req.params.id
            );

            if (!ambiente) {
                return res.status(404).json({
                    erro: "Ambiente não encontrado."
                });
            }

            await ambienteService.deletar(req.params.id);

            res.status(204).send();

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao deletar ambiente."
            });
        }
    }
}

module.exports = new AmbienteController();