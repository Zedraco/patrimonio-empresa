const setorService = require("../services/setorService");

class SetorController {

    async listar(req, res) {

        try {

            const setores = await setorService.listar();

            res.json(setores);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao listar setores."
            });

        }
    }

    async buscarPorId(req, res) {

        try {

            const setor = await setorService.buscarPorId(
                req.params.id
            );

            if (!setor) {
                return res.status(404).json({
                    erro: "Setor não encontrado."
                });
            }

            res.json(setor);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao buscar setor."
            });
        }
    }

    async criar(req, res) {

        try {

            const setor = await setorService.criar(req.body);

            res.status(201).json(setor);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }

    async atualizar(req, res) {

        try {

            const setor = await setorService.atualizar(
                req.params.id,
                req.body
            );

            if (!setor) {
                return res.status(404).json({
                    erro: "Setor não encontrado."
                });
            }

            res.json(setor);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }

    async deletar(req, res) {

        try {

            const setor = await setorService.buscarPorId(
                req.params.id
            );

            if (!setor) {
                return res.status(404).json({
                    erro: "Setor não encontrado."
                });
            }

            await setorService.deletar(req.params.id);

            res.status(204).send();

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao deletar setor."
            });
        }
    }
}

module.exports = new SetorController();