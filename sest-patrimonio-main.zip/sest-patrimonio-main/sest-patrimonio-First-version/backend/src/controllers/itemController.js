const itemService = require("../services/itemService");

class ItemController {

    async listar(req, res) {

        try {

            const itens = await itemService.listar();

            res.json(itens);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao listar itens."
            });
        }
    }

    async buscarPorId(req, res) {

        try {

            const item = await itemService.buscarPorId(
                req.params.id
            );

            if (!item) {
                return res.status(404).json({
                    erro: "Item não encontrado."
                });
            }

            res.json(item);

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao buscar item."
            });
        }
    }

    async criar(req, res) {

        try {

            const item = await itemService.criar(req.body);

            res.status(201).json(item);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }

    async atualizar(req, res) {

        try {

            const item = await itemService.atualizar(
                req.params.id,
                req.body
            );

            if (!item) {
                return res.status(404).json({
                    erro: "Item não encontrado."
                });
            }

            res.json(item);

        } catch (erro) {

            console.error(erro);

            res.status(400).json({
                erro: erro.message
            });
        }
    }



    async listarPatrimonio(req, res) {
    try {

        const patrimonio =
            await itemService.listarPatrimonio();

        res.json(patrimonio);

    } catch (err) {

        console.error(err);

        res.status(500).json({
            erro: "Erro ao listar patrimônio."
        });
    }
}
    async deletar(req, res) {

        try {

            const item = await itemService.buscarPorId(
                req.params.id
            );

            if (!item) {
                return res.status(404).json({
                    erro: "Item não encontrado."
                });
            }

            await itemService.deletar(req.params.id);

            res.status(204).send();

        } catch (erro) {

            console.error(erro);

            res.status(500).json({
                erro: "Erro ao deletar item."
            });
        }
    }
}

module.exports = new ItemController();