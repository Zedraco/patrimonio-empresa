const unidadeService = require("../services/unidadeService");

class UnidadeController {

    async listar(req, res) {

        try {

            const unidades = await unidadeService.listar();

            res.json(unidades);

        } catch (erro) {

            res.status(500).json({
                erro: erro.message
            });

        }

    }

    async buscarPorId(req, res) {

        try {

            const unidade = await unidadeService.buscarPorId(req.params.id);

            if (!unidade) {

                return res.status(404).json({
                    erro: "Unidade não encontrada."
                });

            }

            res.json(unidade);

        } catch (erro) {

            res.status(500).json({
                erro: erro.message
            });

        }

    }

    async criar(req, res) {

        try {

            const unidade = await unidadeService.criar(req.body);

            res.status(201).json(unidade);

        } catch (erro) {

            res.status(400).json({
                erro: erro.message
            });

        }

    }

    async atualizar(req, res) {

        try {

            const unidade = await unidadeService.atualizar(
                req.params.id,
                req.body
            );

            res.json(unidade);

        } catch (erro) {

            res.status(400).json({
                erro: erro.message
            });

        }

    }

    async deletar(req, res) {

        try {

            await unidadeService.deletar(req.params.id);

            res.sendStatus(204);

        } catch (erro) {

            res.status(400).json({
                erro: erro.message
            });

        }

    }

}

module.exports = new UnidadeController();