require("dotenv").config();

const app = require("./app");
const pool = require("./config/db");

const PORT = process.env.PORT || 3000;

async function start() {
    try {

        await pool.query("SELECT NOW()");

        console.log(" Banco conectado.");

        app.listen(PORT, () => {
            console.log(` Servidor iniciado na porta ${PORT}`);
        });

    } catch (err) {

        console.error("Erro ao conectar ao banco:");
        console.error(err);

    }
}

start();