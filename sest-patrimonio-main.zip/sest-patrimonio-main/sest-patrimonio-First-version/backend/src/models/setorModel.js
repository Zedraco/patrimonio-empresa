const db = require("../config/db");

async function listar() {
    const result = await db.query(`
        SELECT
            s.id,
            s.nome,
            s.descricao,
            s.unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            s.created_at,
            s.updated_at
        FROM setores s
        INNER JOIN unidades u ON u.id = s.unidade_id
        ORDER BY s.id
    `);

    return result.rows;
}

async function buscarPorId(id) {
    const result = await db.query(`
        SELECT
            s.id,
            s.nome,
            s.descricao,
            s.unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            s.created_at,
            s.updated_at
        FROM setores s
        INNER JOIN unidades u ON u.id = s.unidade_id
        WHERE s.id = $1
    `, [id]);

    return result.rows[0];
}

async function criar(nome, descricao, unidade_id) {
    const result = await db.query(`
        INSERT INTO setores (
            nome,
            descricao,
            unidade_id
        )
        VALUES ($1, $2, $3)
        RETURNING *
    `, [
        nome,
        descricao || null,
        unidade_id
    ]);

    return result.rows[0];
}

async function atualizar(id, nome, descricao, unidade_id) {
    const result = await db.query(`
        UPDATE setores
        SET
            nome = $1,
            descricao = $2,
            unidade_id = $3,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $4
        RETURNING *
    `, [
        nome,
        descricao || null,
        unidade_id,
        id
    ]);

    return result.rows[0];
}

async function deletar(id) {
    await db.query(
        "DELETE FROM setores WHERE id = $1",
        [id]
    );
}

module.exports = {
    listar,
    buscarPorId,
    criar,
    atualizar,
    deletar
};