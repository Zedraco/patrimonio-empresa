const db = require("../config/db");

async function listar() {
    const result = await db.query(`
        SELECT
            i.id,
            i.codigo_patrimonio,
            i.nome,
            i.descricao,
            i.quantidade,
            i.ambiente_id,
            a.codigo AS ambiente_codigo,
            a.nome AS ambiente_nome,
            a.tipo AS ambiente_tipo,
            s.id AS setor_id,
            s.nome AS setor_nome,
            u.id AS unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            i.created_at,
            i.updated_at
        FROM itens i
        INNER JOIN ambientes a
            ON a.id = i.ambiente_id
        INNER JOIN setores s
            ON s.id = a.setor_id
        INNER JOIN unidades u
            ON u.id = s.unidade_id
        ORDER BY i.id;
    `);

    return result.rows;
}


async function listarPorAmbiente(ambiente_id) {
    const result = await db.query(`
        SELECT
            i.id,
            i.codigo_patrimonio,
            i.nome,
            i.descricao,
            i.quantidade,
            i.ambiente_id,
            a.codigo AS ambiente_codigo,
            a.nome AS ambiente_nome,
            a.tipo AS ambiente_tipo,
            s.id AS setor_id,
            s.nome AS setor_nome,
            u.id AS unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            i.created_at,
            i.updated_at
        FROM itens i
        INNER JOIN ambientes a
            ON a.id = i.ambiente_id
        INNER JOIN setores s
            ON s.id = a.setor_id
        INNER JOIN unidades u
            ON u.id = s.unidade_id
        WHERE i.ambiente_id = $1
        ORDER BY i.id;
    `, [ambiente_id]);

    return result.rows;
}


async function buscarPorId(id) {
    const result = await db.query(`
        SELECT
            i.id,
            i.codigo_patrimonio,
            i.nome,
            i.descricao,
            i.quantidade,
            i.ambiente_id,
            a.codigo AS ambiente_codigo,
            a.nome AS ambiente_nome,
            s.id AS setor_id,
            s.nome AS setor_nome,
            u.id AS unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            i.created_at,
            i.updated_at
        FROM itens i
        INNER JOIN ambientes a
            ON a.id = i.ambiente_id
        INNER JOIN setores s
            ON s.id = a.setor_id
        INNER JOIN unidades u
            ON u.id = s.unidade_id
        WHERE i.id = $1;
    `, [id]);

    return result.rows[0];
}


async function criar(
    codigo_patrimonio,
    nome,
    descricao,
    quantidade,
    ambiente_id
) {
    const result = await db.query(`
        INSERT INTO itens (
            codigo_patrimonio,
            nome,
            descricao,
            quantidade,
            ambiente_id
        )
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *;
    `, [
        codigo_patrimonio,
        nome,
        descricao || null,
        quantidade || 1,
        ambiente_id
    ]);

    return result.rows[0];
}


async function atualizar(
    id,
    codigo_patrimonio,
    nome,
    descricao,
    quantidade,
    ambiente_id
) {
    const result = await db.query(`
        UPDATE itens
        SET
            codigo_patrimonio = $1,
            nome = $2,
            descricao = $3,
            quantidade = $4,
            ambiente_id = $5,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $6
        RETURNING *;
    `, [
        codigo_patrimonio,
        nome,
        descricao || null,
        quantidade,
        ambiente_id,
        id
    ]);

    return result.rows[0];
}


async function deletar(id) {
    await db.query(
        "DELETE FROM itens WHERE id = $1",
        [id]
    );
}


async function listarPatrimonio() {
    const result = await db.query(`
        SELECT
            i.id,
            i.codigo_patrimonio,
            i.nome,
            i.descricao,
            i.quantidade,
            i.created_at,
            i.updated_at,

            a.id AS ambiente_id,
            a.codigo AS ambiente_codigo,
            a.nome AS ambiente_nome,
            a.tipo AS ambiente_tipo,

            s.id AS setor_id,
            s.nome AS setor_nome,

            u.id AS unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo

        FROM itens i

        INNER JOIN ambientes a
            ON i.ambiente_id = a.id

        INNER JOIN setores s
            ON a.setor_id = s.id

        INNER JOIN unidades u
            ON s.unidade_id = u.id

        ORDER BY i.id;
    `);

    return result.rows;
}


module.exports = {
    listar,
    listarPorAmbiente,
    buscarPorId,
    criar,
    atualizar,
    deletar,
    listarPatrimonio
};