const db = require("../config/db");

async function listar() {
    const result = await db.query(
        "SELECT * FROM unidades ORDER BY id"
    );

    return result.rows;
}

async function buscarPorId(id) {

    const result = await db.query(

        "SELECT * FROM unidades WHERE id=$1",

        [id]

    );

    return result.rows[0];

}

async function criar(nome, tipo) {

    const result = await db.query(

        `INSERT INTO unidades
        (nome,tipo)
        VALUES ($1,$2)
        RETURNING *`,

        [nome,tipo]

    );

    return result.rows[0];

}

async function atualizar(id,nome,tipo){

    const result = await db.query(

        `UPDATE unidades

        SET nome=$1,

        tipo=$2

        WHERE id=$3

        RETURNING *`,

        [nome,tipo,id]

    );

    return result.rows[0];

}

async function deletar(id){

    await db.query(

        "DELETE FROM unidades WHERE id=$1",

        [id]

    );

}

module.exports={

listar,

buscarPorId,

criar,

atualizar,

deletar

}