const db = require("../config/db");

async function listar() {
    const result = await db.query(`
        SELECT
            a.id,
            a.codigo,
            a.nome,
            a.tipo,
            a.descricao,
            a.setor_id,
            s.nome AS setor_nome,
            s.unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            a.created_at,
            a.updated_at
        FROM ambientes a
        INNER JOIN setores s ON s.id = a.setor_id
        INNER JOIN unidades u ON u.id = s.unidade_id
        ORDER BY a.id
    `);

    return result.rows;
}

async function buscarPorId(id) {
    const result = await db.query(`
        SELECT
            a.id,
            a.codigo,
            a.nome,
            a.tipo,
            a.descricao,
            a.setor_id,
            s.nome AS setor_nome,
            s.unidade_id,
            u.nome AS unidade_nome,
            u.tipo AS unidade_tipo,
            a.created_at,
            a.updated_at
        FROM ambientes a
        INNER JOIN setores s ON s.id = a.setor_id
        INNER JOIN unidades u ON u.id = s.unidade_id
        WHERE a.id = $1
    `, [id]);

    return result.rows[0];
}

async function criar(codigo, nome, tipo, descricao, setor_id) {
    const result = await db.query(`
        INSERT INTO ambientes (
            codigo,
            nome,
            tipo,
            descricao,
            setor_id
        )
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *
    `, [
        codigo,
        nome,
        tipo,
        descricao || null,
        setor_id
    ]);

    return result.rows[0];
}

async function atualizar(id, codigo, nome, tipo, descricao, setor_id) {
    const result = await db.query(`
        UPDATE ambientes
        SET
            codigo = $1,
            nome = $2,
            tipo = $3,
            descricao = $4,
            setor_id = $5,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $6
        RETURNING *
    `, [
        codigo,
        nome,
        tipo,
        descricao || null,
        setor_id,
        id
    ]);

    return result.rows[0];
}

async function deletar(id) {
    await db.query(
        "DELETE FROM ambientes WHERE id = $1",
        [id]
    );
}

module.exports = {
    listar,
    buscarPorId,
    criar,
    atualizar,
    deletar
};