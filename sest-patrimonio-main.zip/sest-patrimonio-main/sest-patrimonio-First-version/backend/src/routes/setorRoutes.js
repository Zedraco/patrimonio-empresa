const express = require("express");

const router = express.Router();

const setorController = require("../controllers/setorController");

router.get(
    "/setores",
    setorController.listar
);

router.post(
    "/setores",
    setorController.criar
);

router.get(
    "/setores/:id",
    setorController.buscarPorId
);

router.put(
    "/setores/:id",
    setorController.atualizar
);

router.delete(
    "/setores/:id",
    setorController.deletar
);

module.exports = router;