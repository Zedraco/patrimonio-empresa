const express = require("express");

const router = express.Router();

const unidadeController = require("../controllers/unidadeController");

router.get("/unidades", unidadeController.listar);

router.post("/unidades", unidadeController.criar);

router.get("/unidades/:id",unidadeController.buscarPorId);

router.put("/unidades/:id",unidadeController.atualizar);

router.delete("/unidades/:id", unidadeController.deletar)

module.exports = router;