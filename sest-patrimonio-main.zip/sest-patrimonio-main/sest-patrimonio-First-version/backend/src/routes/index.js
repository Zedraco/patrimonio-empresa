const express = require("express");

const router = express.Router();

const unidadeRoutes = require("./unidadeRoutes");

const setorRoutes = require("./setorRoutes");

const ambienteRoutes = require("./ambienteRoutes");

const itemRoutes = require("./itemRoutes");

router.use(unidadeRoutes);
router.use(setorRoutes);
router.use(ambienteRoutes);
router.use(itemRoutes);

module.exports = router;