const express = require("express");

const router = express.Router();

const itemController = require("../controllers/itemController");

router.get(
    "/itens",
    itemController.listar
);

router.get(
    "/patrimonio",
    itemController.listarPatrimonio
);

router.post(
    "/itens",
    itemController.criar
);

router.get(
    "/itens/:id",
    itemController.buscarPorId
);

router.put(
    "/itens/:id",
    itemController.atualizar
);

router.delete(
    "/itens/:id",
    itemController.deletar
);

module.exports = router;