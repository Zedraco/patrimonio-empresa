const express = require("express");

const router = express.Router();

const ambienteController = require("../controllers/ambienteController");

router.get(
    "/ambientes",
    ambienteController.listar
);

router.post(
    "/ambientes",
    ambienteController.criar
);

router.get(
    "/ambientes/:id",
    ambienteController.buscarPorId
);

router.put(
    "/ambientes/:id",
    ambienteController.atualizar
);

router.delete(
    "/ambientes/:id",
    ambienteController.deletar
);

module.exports = router;